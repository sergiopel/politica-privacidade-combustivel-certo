# Política de Privacidade – Combustível Certo

Este repositório publica a página de **Política de Privacidade** do app *Combustível Certo* via **GitHub Pages**.

## Como publicar

1. Crie o repositório no GitHub (público), por exemplo: `politica-privacidade-combustivel-certo`.
2. Envie estes arquivos (`index.html`, `.nojekyll`) para a branch `main`.
3. No GitHub: **Settings → Pages → Build and deployment**:
   - **Source:** *Deploy from a branch*
   - **Branch:** `main` — **Folder:** `/ (root)`
4. Aguarde a publicação. A URL ficará assim:  
   `https://<seu-usuario>.github.io/politica-privacidade-combustivel-certo/`

> Para o usuário **sergiopel**, a URL será:  
> `https://sergiopel.github.io/politica-privacidade-combustivel-certo/`

## Editar e-mail de contato
No arquivo `index.html`, procure por `seu-email@exemplo.com` e substitua pelo seu e-mail.

## Histórico
- Última atualização do documento: 09/09/2025.
